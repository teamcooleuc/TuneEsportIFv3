using System;
using Microsoft.EntityFrameworkCore;
using TuneEsportIFv2.Data;
using TuneEsportIFv2.Models;
using Xunit;

namespace EsportUnitTest

{
    public class EFTestDataService
    {
        protected DbContextOptions<ApplicationDbContext> ContextOptions { get; }

        protected EFTestDataService(DbContextOptions<ApplicationDbContext> contextOptions)
        {
            ContextOptions = contextOptions;
            Seed();
        }

        private void Seed()
        {
            using (var context = new ApplicationDbContext(ContextOptions))
            {
                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();
                context.TrainingStats.Add(new TrainingStats() { TrainingStatId = 1, Tactics = "Good", Smokes = 20, EconomyKnowledge = "Bad", mapKnowledge = "Good", mapsName = "Dust"});
                context.TrainingStats.Add(new TrainingStats() { TrainingStatId = 2, Tactics = "Bad", Smokes = 15, EconomyKnowledge = "Super", mapKnowledge = "Bad", mapsName = "Dust" });


                context.SaveChanges();
            }
        }
    }
}
