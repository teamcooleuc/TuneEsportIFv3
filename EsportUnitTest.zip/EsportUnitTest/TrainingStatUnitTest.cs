﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using TuneEsportIFv2.Data;
using TuneEsportIFv2.Models;
using TuneEsportIFv2.Services.EFServices;
using Xunit;

namespace EsportUnitTest
{
    public class TrainingStatUnitTest : EFTestDataService
    {

        public TrainingStatUnitTest() : base(new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase("Filename=Test.db").Options)
        {

        }



        [Fact]
        public void Get_All_TrainingStats_Test()
        {
            using (var context = new ApplicationDbContext(ContextOptions))
            {
                EFTrainingStatService tService = new EFTrainingStatService(context);

                var trainingStat = tService.GetAllTrainingStats().ToList();
                Assert.Equal(2, trainingStat.Count);
                Assert.Equal("Good", trainingStat[0].Tactics);
                Assert.Equal("Bad", trainingStat[1].Tactics);
            }
        }

        [Fact]
        public void Add_A_TrainingStat_Test()
        {
            using (var context = new ApplicationDbContext(ContextOptions))
            {
                EFTrainingStatService tService = new EFTrainingStatService(context);

                tService.AddTrainingStat(new TrainingStats() { TrainingStatId = 3, Tactics = "Test", Smokes = 15, EconomyKnowledge = "Super", mapKnowledge = "Bad", mapsName = "Dust" });
                var trainingStats = tService.GetAllTrainingStats().ToList();
                Assert.True(trainingStats.Count == 3);
                Assert.Equal("Test", trainingStats[2].Tactics);
            }
        }

        [Fact]
        public void Delete_A_TrainingStat_Test()
        {
            using (var context = new ApplicationDbContext(ContextOptions))
            {
                EFTrainingStatService tService = new EFTrainingStatService(context);

                var trainingStat = tService.GetAllTrainingStats().Where(t => t.TrainingStatId == 2).FirstOrDefault();
                tService.DeleteTrainingStat(trainingStat);
                var trainingStats = tService.GetAllTrainingStats().ToList();
                Assert.True(trainingStats.Count == 1);
                Assert.False(trainingStats[0].Tactics== "Bad");
            }
        }


        [Fact]
        public void Get_TrainingStat_By_TrainingStatById_Test()
        {
            using (var context = new ApplicationDbContext(ContextOptions))
            {
                EFTrainingStatService tService = new EFTrainingStatService(context);

                var trainingStats = tService.GetAllTrainingStats().Where(t => t.TrainingStatId == 10);
                Assert.True(trainingStats.ToList().Count == 0);

            }
        }
    }
}
